package com.example.appproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button LogIn;
    Button SignUp;
    TextView CDT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LogIn = findViewById(R.id.login);
        SignUp = findViewById(R.id.signup);
        CDT = findViewById(R.id.tvCDT);

        LogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent1);
            }
        });

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent2);
            }
        });

        CountDownTimer cdt = new CountDownTimer(10000, 1000){
            @Override
            public void onTick(long millisUntilFinished) {
                String stCountDown ="" + millisUntilFinished/1000;
                CDT.setText("Starts in " + stCountDown + " seconds");
            }

            @Override
            public void onFinish() {
                CDT.setText("Done!");
                LogIn.callOnClick();
            }
        }.start();
    }
}